Here you will find the sample report to solve the challenge
